from PyQt6.QtWidgets import *

from PyQt6.uic import loadUi
import sys # used to pass arguements
import os

from PyQt6.QtPrintSupport import *
from PyQt6.QtGui import *
from PyQt6.QtWidgets import *




###############################
##Printer code seem not to be working too well.

#This notepad application uses the UI file
##############################

class Main(QMainWindow):
    def __init__(self):
        super(Main, self).__init__()
        loadUi("notepad.ui", self)

        try:
            self.current_path = None
            self.setWindowTitle("Untitled")
            self.currentFontSize = 8

            # Connect menu actions to their respective slots
            self.actionNew.triggered.connect(self.newFile)
            self.actionClose.triggered.connect(self.closeFile)
            self.actionSave.triggered.connect(self.saveFile)
            self.actionSave_As.triggered.connect(self.saveFileAs)
            self.actionOpen.triggered.connect(self.openFile)
            self.actionUndo.triggered.connect(self.undo)
            self.actionRedo.triggered.connect(self.redo)
            self.actionCopy.triggered.connect(self.copy)
            self.actionCut.triggered.connect(self.cut)
            self.actionPaste.triggered.connect(self.paste)
            self.actionSet_Dark_Mode.triggered.connect(self.setDarkMode)
            self.actionSet_Light_Mode.triggered.connect(self.setLightMode)
            self.actionClear.triggered.connect(self.clear)
            self.actionChange_Font.triggered.connect(self.incFontSize)
            self.actionReduce_Font.triggered.connect(self.decFontSize)
            self.actionPrint.triggered.connect(self.printpage)

        except ValueError as e:
            print("ValueError:", e)
            # Handle the exception or log the error message here

    def newFile(self):
        self.textEdit.clear()
        self.setWindowTitle("Untitled")
        self.current_path = None

    def closeFile(self):
        self.close()

    def saveFile(self):
        if self.current_path is not None:
            # Save the changes without opening the dialog
            filetext = self.textEdit.toPlainText()
            with open(self.current_path, 'w') as f:
                f.write(filetext)
        else:
            self.saveFileAs()

    def saveFileAs(self):
        pathname, _ = QFileDialog.getSaveFileName(self, 'Save file', 'C:\ ', 'Text files(*.txt)')
        if pathname:
            filetext = self.textEdit.toPlainText()
            with open(pathname, 'w') as f:
                f.write(filetext)
            self.current_path = pathname
            self.setWindowTitle(pathname)

    def openFile(self):
        try:
            fname, _ = QFileDialog.getOpenFileName(self, 'Open file', 'C:\ ', 'Text files (*.txt)')
            self.setWindowTitle(fname)
            with open(fname, 'r') as f:
                filetext = f.read()
                self.textEdit.setText(filetext)
            self.current_path = fname
        except Exception as e:
            print("Error:", e)
            # Handle the exception or display an error message

    def undo(self):
        self.textEdit.undo()

    def redo(self):
        self.textEdit.redo()

    def copy(self):
        self.textEdit.copy()

    def cut(self):
        self.textEdit.cut()

    def clear(self):
        self.textEdit.clear()

    def paste(self):
        self.textEdit.paste()

    def setDarkMode(self):
        self.setStyleSheet('''
            QWidget {
                background-color: rgb(33, 33, 33);
                color: #FFFFFF;
            }
            QTextEdit {
                background-color: rgb(46, 46, 46);
            }
            QMenuBar::item:selected {
                color: #000000;
            }
        ''')

    def setLightMode(self):
        self.setStyleSheet("")

    def incFontSize(self):
        self.currentFontSize += 1
        self.textEdit.setFontPointSize(self.currentFontSize)

    def decFontSize(self):
        self.currentFontSize -= 1
        self.textEdit.setFontPointSize(self.currentFontSize)

    def printpage(self):
        dialog = QPrintDialog()
        if dialog.exec() == QPrintDialog.PrintDialogAccepted:
            self.textEdit.print_(dialog.printer())


if __name__ == '__main__':
    app = QApplication(sys.argv)
    ui = Main()
    ui.show()
    sys.exit(app.exec())
